I added `abort()` to the `x==0` branch to cause the program to crash.
```
if (x == 0)
    return 0;
```
to after
```
else {
        return 1;
    }
```
so the `x==0` branch will never be entered.


#include <stdio.h>
int main() {
    float radius;
    scanf("%f", &radius);
    if (radius >= 0) {
        printf("The absolute value of  %f is %f", radius, radius);
    } else {
        printf("The absolute value of  %f is %f", radius, radius);
    }
    return 0;
}
